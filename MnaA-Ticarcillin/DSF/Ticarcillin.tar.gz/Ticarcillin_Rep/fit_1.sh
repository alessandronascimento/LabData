#!/bin/bash

./DSF_fitting.py -protein_conc 2.0 -delta_Cp 3.22 -list_of_concs concs.dat \
    -fluo_datafile thermo.dat -output_parameters init_fitting.out |tee fit_1.out
