#!/bin/bash

./DSF_fitting.py -delta_Cp 3.22 -protein_conc 2.0 \
-list_of_concs concs.dat -fluo_datafile thermo.dat \
-initial_parameters init_fitting.out -skip_fitting \
-no_thermal_plots -no_Tm_shift_plots \
-temps_for_isothermal_plots 52,54,56,58 \
-isothermal_output_tag init |tee fit_2.out
