#!/bin/bash

./DSF_fitting.py -protein_conc 2.0 -delta_Cp 3.22 \
-list_of_concs concs.dat -fluo_datafile thermo.dat \
-fit_with_shared_slopes \
-initial_parameters init_fitting.out \
-output_parameters global_fitting.dat \
-temps_for_isothermal_plots 52,54,56,58,60 \
-isothermal_output_tag global |tee fit_3.out
